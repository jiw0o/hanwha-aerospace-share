# read world file and double the x,y,z values of pose frame using regular expression

import re
import os

# define input and output file paths
working_dir = "/media/j/T7/git/hanwha/src/natural_enviroments/worlds/"
input_file = "hill.world"
output_file = "hill_v1.world"

# define scale factor
scale = 2

if os.path.isfile(output_file):
    os.remove(output_file)

# define the pattern to match
pattern_pose = re.compile(r"(\s+)<pose frame=''>([a-zA-Z0-9-.]+)\s+([a-zA-Z0-9-.]+)\s+([a-zA-Z0-9-.]+)\s+([a-zA-Z0-9-.]+)\s+([a-zA-Z0-9-.]+)\s+([a-zA-Z0-9-.]+)</pose>")

def modify_pose(match, scale):
    indent, x, y, z, p, q, r = match.groups()
    x, y, z = map(float, (x, y, z))
    x = x * scale
    y = y * scale
    z = z * scale
    modifed_line = indent + f"<pose frame=''>{x} {y} {z} {p} {q} {r}</pose>" + "\n" 
    return modifed_line

with open(working_dir + input_file, 'r') as input_file, open(working_dir + output_file, 'w') as output_file:
    for line in input_file:
        match_pose = pattern_pose.match(line)
        if match_pose:
            output_file.write(modify_pose(match_pose, scale))
        else:
            output_file.write(line)
