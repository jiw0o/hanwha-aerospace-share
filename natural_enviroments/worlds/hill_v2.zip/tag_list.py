sky ="""
      <sky>
        <clouds>
          <speed>12</speed>
        </clouds>
      </sky>"""

sky_tagged ="\n"

hill ="""
          <material>
            <script>
              <uri>model://hill/materials/scripts</uri>
              <uri>model://hill/materials/textures</uri>
              <name>vrc/hill</name>
            </script>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>1</laser_retro>"""

hill_tagged ="""
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>0 1 0 1</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>0</laser_retro>"""

lago ="""
          <material>
            <script>
              <uri>model://lago3/materials/scripts</uri>
              <uri>model://lago3/materials/textures</uri>
              <name>vrc/agua</name>
            </script>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>120</laser_retro>"""

lago_tagged ="""
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>0.129 0.435 0.698</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>0</laser_retro>"""

tree_bark ="""
          <geometry>
            <mesh>
              <uri>model://tree_8/bark8.obj</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>2</laser_retro>"""

tree_bark_tagged ="""
          <geometry>
            <mesh>
              <uri>model://tree_8/bark8.obj</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 0 1 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>0</laser_retro>"""

tree_crown ="""
          <geometry>
            <mesh>
              <uri>model://tree_8/crown8.obj</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>3</laser_retro>"""

tree_crown_tagged ="""
          <geometry>
            <mesh>
              <uri>model://tree_8/crown8.obj</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 1 0 1</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>0</laser_retro>"""

arbol_copa ="""
          <geometry>
            <mesh>
              <uri>model://arbol3_dry/copa3.dae</uri>
              <scale>0.5 0.5 0.5</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>3</laser_retro>"""

arbol_copa_tagged ="""
          <geometry>
            <mesh>
              <uri>model://arbol3_dry/copa3.dae</uri>
              <scale>0.5 0.5 0.5</scale>
            </mesh>
          </geometry>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 1 0 1</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>80</laser_retro>"""

arbol_toronco ="""
          <geometry>
            <mesh>
              <uri>model://arbol3_dry/tronco3.dae</uri>
              <scale>0.5 0.5 0.5</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>2</laser_retro>"""

arbol_toronco_tagged ="""
          <geometry>
            <mesh>
              <uri>model://arbol3_dry/tronco3.dae</uri>
              <scale>0.5 0.5 0.5</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 0 1 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>90</laser_retro>"""

roca_20 ="""
          <geometry>
            <mesh>
              <uri>model://roca3/model.dae</uri>
              <scale>20 20 20</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>5</laser_retro>"""

roca_20_tagged ="""
          <geometry>
            <mesh>
              <uri>model://roca3/model.dae</uri>
              <scale>20 20 20</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 0 0 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>40</laser_retro>"""

arbol_troncot ="""
          <geometry>
            <mesh>
              <uri>model://arbol5/troncot.dae</uri>
              <scale>0.05 0.05 0.05</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>2</laser_retro>"""

arbol_troncot_tagged ="""
          <geometry>
            <mesh>
              <uri>model://arbol5/troncot.dae</uri>
              <scale>0.05 0.05 0.05</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 0 1 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>90</laser_retro>"""

arbol_copaoot ="""
          <geometry>
            <mesh>
              <uri>model://arbol5/copaoot.dae</uri>
              <scale>0.05 0.05 0.05</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>3</laser_retro>"""

arbol_copaoot_tagged ="""
          <geometry>
            <mesh>
              <uri>model://arbol5/copaoot.dae</uri>
              <scale>0.05 0.05 0.05</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 1 0 1</emissive>
          </material>
        </visual>

        <collision name='collision'>
          <laser_retro>80</laser_retro>"""

dry_bush ="""
          <geometry>
            <mesh>
              <uri>model://dry_bush/untitled.obj</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <material>
            <lighting>1</lighting>
            <script>
              <uri>file://media/materials/scripts/gazebo.material</uri>
              <name>Gazebo/Grey</name>
            </script>
            <ambient>0.3961 0.2627 0.1994 1</ambient>
            <diffuse>0.3961 0.2627 0.1994 1</diffuse>
            <specular>0.01 0.1 0.01 1</specular>
            <emissive>0 0 0 1</emissive>
            <shader type='vertex'>
              <normal_map>__default__</normal_map>
            </shader>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>4</laser_retro>"""

dry_bush_tagged ="""
          <geometry>
            <mesh>
              <uri>model://dry_bush/untitled.obj</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>0 0 1 1</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>70</laser_retro>"""

roca_5 ="""
          <geometry>
            <mesh>
              <uri>model://roca3/model.dae</uri>
              <scale>5 5 5</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>5</laser_retro>"""

roca_5_tagged ="""
          <geometry>
            <mesh>
              <uri>model://roca3/model.dae</uri>
              <scale>5 5 5</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 0 0 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>40</laser_retro>"""

roca_1 ="""
          <geometry>
            <mesh>
              <uri>model://roca3/model.dae</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>5</laser_retro>"""

roca_1_tagged ="""
          <geometry>
            <mesh>
              <uri>model://roca3/model.dae</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>1 0 0 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>40</laser_retro>"""

altaniv ="""
          <geometry>
            <mesh>
              <uri>model://altaniv/nivdisppeqdae.dae</uri>
              <scale>1 6 1</scale>
            </mesh>
          </geometry>
          <material>
            <lighting>1</lighting>
            <script>
              <uri>file://media/materials/scripts/gazebo.material</uri>
              <name>Gazebo/Grey</name>
            </script>
            <ambient>0.6627 0.5137 0.0274 1</ambient>
            <diffuse>0.6627 0.5137 0.0274 1</diffuse>
            <specular>0.01 0.1 0.01 1</specular>
            <emissive>0 0 0 1</emissive>
            <shader type='vertex'>
              <normal_map>__default__</normal_map>
            </shader>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>6</laser_retro>"""

altaniv_tagged ="""
          <geometry>
            <mesh>
              <uri>model://altaniv/nivdisppeqdae.dae</uri>
              <scale>1 6 1</scale>
            </mesh>
          </geometry>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>0.38 0.5 0.129 1</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>30</laser_retro>"""

altaniv_secad ="""
          <geometry>
            <mesh>
              <uri>model://altaniv_secad/alta.dae</uri>
              <scale>1 6 1</scale>
            </mesh>
          </geometry>
          <material>
            <lighting>1</lighting>
            <script>
              <uri>file://media/materials/scripts/gazebo.material</uri>
              <name>Gazebo/Grey</name>
            </script>
            <ambient>0.6627 0.5137 0.0274 1</ambient>
            <diffuse>0.6627 0.5137 0.0274 1</diffuse>
            <specular>0.01 0.1 0.01 1</specular>
            <emissive>0 0 0 1</emissive>
            <shader type='vertex'>
              <normal_map>__default__</normal_map>
            </shader>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>6</laser_retro>"""

altaniv_secad_tagged ="""
          <geometry>
            <mesh>
              <uri>model://altaniv_secad/alta.dae</uri>
              <scale>1 6 1</scale>
            </mesh>
          </geometry>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>0.38 0.5 0.129 1</emissive>
          </material>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>30</laser_retro>"""

albusto ="""
          <geometry>
            <mesh>
              <uri>model://arbusto3_dry/model.dae</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
        </visual>
        <collision name='collision'>
          <laser_retro>4</laser_retro>"""

albusto_tagged ="""
          <geometry>
            <mesh>
              <uri>model://arbusto3_dry/model.dae</uri>
              <scale>1 1 1</scale>
            </mesh>
          </geometry>
          <transparency>0</transparency>
          <cast_shadows>1</cast_shadows>
          <material>
            <ambient>0 0 0 1</ambient>
            <diffuse>0 0 0 1</diffuse>
            <specular>0 0 0 0</specular>
            <emissive>0 0 1 1</emissive>
          </material>
        </visual>
        <collision name='collision'>
          <laser_retro>70</laser_retro>"""

tagdic = {sky: sky_tagged,
          hill: hill_tagged,
          lago: lago_tagged,
          tree_bark: tree_bark_tagged, 
          tree_crown: tree_crown_tagged, 
          arbol_copa: arbol_copa_tagged, 
          arbol_toronco: arbol_toronco_tagged,
          roca_20: roca_20_tagged,
          arbol_troncot: arbol_troncot_tagged,
          arbol_copaoot: arbol_copaoot_tagged,
          dry_bush: dry_bush_tagged,
          roca_5: roca_5_tagged,
          roca_1: roca_1_tagged,
          altaniv: altaniv_tagged,
          altaniv_secad: altaniv_secad_tagged,
          albusto: albusto_tagged,
          }