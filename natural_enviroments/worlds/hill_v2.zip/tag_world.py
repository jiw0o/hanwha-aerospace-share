# read world file and replace the strings in the list with the corresponding strings in the dictionary

import os
import tag_list

tagdic = tag_list.tagdic

working_dir = "/media/j/T7/git/hanwha/src/natural_enviroments/worlds/"
input_file = "hill_v2.world"
output_file = "hill_v2_tagged.world"

if os.path.isfile(output_file):
    os.remove(output_file)
    
with open(working_dir + input_file, 'r') as f:
    world = f.read()
    for key, value in tagdic.items():
        world = world.replace(key, value)
    f.close()
with open(working_dir + output_file, 'w') as f:
    f.write(world)
    f.close()
        